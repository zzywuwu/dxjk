int luaopen_des56 (lua_State *L);
